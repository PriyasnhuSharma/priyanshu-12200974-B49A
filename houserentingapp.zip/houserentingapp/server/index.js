const dotenv=require('dotenv');
dotenv.config();

const express=require("express");
const app=express();
const port=5000
app.use(express.json());

const mongoose=require("mongoose");

const router=require('./serverroutes/server_routes.js');
app.use(router);

const cookieparser=require('cookie-parser');
app.use(cookieparser());

const cors=require("cors");
app.use(cors());


// mongoose.connect(process.env.connectmongo,({ useNewUrlParser: true, useUnifiedTopology: true })).then(()=>{
//     console.log("connected to the database");
// })

mongoose.connect("mongodb://localhost:27017/house_rent")
.then(()=>{
    console.log("db connected")
})
.catch(()=>{
    console.log("db not connected")
})

app.get('/',(req,res)=>{
    res.send("home rent");
})

app.listen(port,()=>{
    console.log("server running on port",port);
})